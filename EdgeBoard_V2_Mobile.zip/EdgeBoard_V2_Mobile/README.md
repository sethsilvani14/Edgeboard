
# EdgeBoard V2 — Mobile Prototype

EdgeBoard V2 is a mobile-first Streamlit prototype designed around how the product would actually be used while betting on a phone.

## What's new vs V1
- Thumb-friendly card layout
- FanDuel vs bet365 comparison
- Best-book callout
- Best Bets tab
- Game drill-down tab
- Player Props tab
- My Bets tracker
- Mobile-width layout
- Clear explanation of model probability, EV and book comparison

## Important
Every line, price, recommendation and model output in this prototype is synthetic demo data.

## Run locally
1. Install Python 3.11+
2. Open a terminal in this folder
3. `pip install -r requirements.txt`
4. `streamlit run app.py`
5. Open the local URL on your computer or phone if they're on the same network.

## Better phone deployment
For actual use, deploy the app to a web host (Streamlit Community Cloud, Render, Railway, etc.) and open the HTTPS URL from the phone. Then add it to the home screen.

## V3 direction
- Connect live odds
- Build CFB model first
- Add historical backtesting
- Add closing-line value
- Real result grading
- Expand NFL, NBA, CBB and soccer models
- Add player-prop engines
- Consider live/2H later
